# RubberDucky With a Raspberry Pi Pico
In this Repository, you will find some payloads for Windows And Linux.

To make the basic configuration for a Raspberry Pi Pico:
1. Copy flash_Nuke on you raspberry
2. Copy adafruit-circuitpython on your Raspberry
3. Copy the code.py and delete de one that has created automatically.
4. Delete de lib Directory and copy the one on the repository on the Raspberry
That's all you will need to configure the Raspberry Pi Pico


The basic Structure of a payload on Ducky Script
1. REM to do comments
2. DELAY to put delay on milliseconds
3. STRING to put the string you want
4. ENTER
5. GUI to use de windows key

All the other keys like ALT or CONTROL you will find it on the Keycode.py

REMEMBER, THIS RUBBER DUCKY IS CONFIGURED TO WORK WITH A SPANISH KEYBOARD!
